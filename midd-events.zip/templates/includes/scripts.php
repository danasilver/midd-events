<?php
if (!isset($static_prefix)) {
  $static_prefix = "";
}
?>
<script src="<?php echo $static_prefix; ?>static/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo $static_prefix; ?>static/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo $static_prefix; ?>static/select2/select2.min.js"></script>
<script src="<?php echo $static_prefix; ?>static/datepicker/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo $static_prefix; ?>static/js/main.js"></script>