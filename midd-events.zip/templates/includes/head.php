<?php
if (!isset($static_prefix)) {
  $static_prefix = "";
}
?>
<head>
<title><?php echo $title ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo $static_prefix; ?>static/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $static_prefix; ?>static/select2/select2.css" rel="stylesheet">
<link href="<?php echo $static_prefix; ?>static/datepicker/bootstrap-datetimepicker.min.css" rel="stylesheet">
<link href="<?php echo $static_prefix; ?>static/css/main.css" rel="stylesheet">
</head>